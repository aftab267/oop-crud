<?php
require_once('classes/user.php');
$user=new user();

$id=$_GET['id'];

$data=$user->update_user($id);
$data=mysqli_fetch_assoc($data);

if(isset($_POST['save_user'])){
    $user->update_user_save($_POST);
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<form action="" method="POST">
	<input type="hidden" name="id" value="<?= $data['id'] ?>"><br><br>
	<input type="text" name="name" placeholder="Name" value="<?= $data['name'] ?>"><br><br>
	<input type="email" name="email" placeholder="email" value="<?= $data['email'] ?>"><br><br>
	<input type="submit" value="Update user" name="save_user">
</form>
</body>
</html>