<?php

require_once('classes/user.php');


$user=new user();
if(isset($_POST['save_user'])){
    $message=$user->save_users($_POST);
}
$all_users=$user->all_users();

?>



<form action="" method="POST">
	<input type="text" name="name" placeholder="Name"><br><br>
	<input type="email" name="email" placeholder="email"><br><br>
	<input type="password" name="password" placeholder="password"><br><br>
	<input type="submit" value="Save user" name="save_user">
</form>

<hr/>
<table border>
	<tr>
		<td>SL</td>
		<td>Name</td>
		<td>Email</td>
		<td>Action</td>
	</tr>
     <?php
      $x=1;
      while($row=mysqli_fetch_assoc($all_users)){
      	?>     
	<tr>
		<td><?php echo $x++ ?> </td>
		<td><?php echo $row['name'] ?> </td>
		<td><?php echo $row['email'] ?> </td>
		<td>
          <a href="edit.php?id=<?= $row['id'] ?>">Edit</a>
          <a href="delete.php?id=<?=$row['id'] ?>">Delete</a>
		</td>
	</tr>
	 <?php
      };
     ?>


</table>



