<?php

class user{     

     public function __construct(){
         $this->link=mysqli_connect('localhost','root','','oop');
     }
     public function save_users($data){
          $name=$_POST['name'];
          $email=$_POST['email'];
          $password=$_POST['password'];
          $query="INSERT INTO users (name,email,password) VALUES('$name','$email','$password')";
          mysqli_query($this->link,$query);
          
     }

     public function all_users(){
          
          return mysqli_query($this->link,"SELECT * FROM users");
     }
     public function delete_users($id){
          mysqli_query($this->link,"DELETE FROM users WHERE id='$id'");
          header('location:index.php');
    }
    public function update_user($id){
          return mysqli_query($this->link,"SELECT * FROM users WHERE id='$id'");
}
public function update_user_save($data){
          $id=$_POST['id'];
          $name=$_POST['name'];
          $email=$_POST['email'];
          mysqli_query($this->link,"UPDATE users SET name='$name',email='$email' where id='$id'");
          header('location:index.php');
}
}

